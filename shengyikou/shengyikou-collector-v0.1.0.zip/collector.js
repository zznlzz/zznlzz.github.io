/* global chrome */

const PLATFORM_RULES = [
  { host: "meituan.com", platform: "美团" },
  { host: "jd.com", platform: "京东" },
  { host: "taobao.com", platform: "淘宝" },
  { host: "ele.me", platform: "饿了么" },
];

const MONEY_PATTERN = /(?:¥|￥|元)?\s*(\d{1,4}(?:\.\d{1,2})?)\s*(?:元)?/;
const MONEY_GLOBAL_PATTERN = /(?:¥|￥)\s*(\d{1,4}(?:\.\d{1,2})?)/g;

function cleanText(value) {
  return String(value || "").replace(/\s+/g, " ").trim();
}

function parseMoney(value) {
  const match = cleanText(value).match(MONEY_PATTERN);
  const amount = match ? Number(match[1]) : NaN;
  return Number.isFinite(amount) && amount >= 0 && amount <= 2000 ? amount : null;
}

function visibleText(element) {
  if (!element) return "";
  const style = window.getComputedStyle(element);
  if (style.display === "none" || style.visibility === "hidden") return "";
  return cleanText(element.innerText || element.textContent);
}

function findLabeledAmount(labels) {
  const elements = [...document.querySelectorAll("body *")];
  for (const element of elements) {
    const ownText = cleanText(element.childNodes.length === 1 ? element.textContent : "");
    if (!ownText || ownText.length > 30 || !labels.some((label) => ownText.includes(label))) continue;

    let current = element;
    for (let depth = 0; current && depth < 3; depth += 1, current = current.parentElement) {
      const text = visibleText(current);
      if (text.length > 160) continue;
      const candidates = [...text.matchAll(MONEY_GLOBAL_PATTERN)].map((match) => Number(match[1]));
      if (candidates.length) return candidates.at(-1);
      const plain = parseMoney(text.replace(ownText, ""));
      if (plain !== null) return plain;
    }
  }
  return null;
}

function prominentPrice() {
  const selectors = [
    "[class*='total'] [class*='price']",
    "[class*='pay'] [class*='price']",
    "[class*='Price']",
    "[class*='price']",
    "[data-price]",
  ];
  const values = [];
  for (const selector of selectors) {
    for (const element of document.querySelectorAll(selector)) {
      const raw = element.getAttribute("data-price") || visibleText(element);
      const amount = parseMoney(raw);
      if (amount !== null && amount > 0) values.push(amount);
    }
  }
  return values.find((value) => value >= 5 && value <= 500) ?? values[0] ?? null;
}

function findName(selectors, fallback) {
  for (const selector of selectors) {
    const element = document.querySelector(selector);
    const text = visibleText(element);
    if (text && text.length >= 2 && text.length <= 80) return text;
  }
  return cleanText(fallback).slice(0, 80);
}

function detectChannel(bodyText) {
  if (/拼好饭/.test(bodyText)) return "拼好饭";
  if (/神抢手|神枪手/.test(bodyText)) return "神抢手";
  if (/到店自取|门店自取|自取/.test(bodyText)) return "到店自取";
  if (/团购|券码|到店核销/.test(bodyText)) return "团购券";
  if (/闪购/.test(bodyText)) return "闪购";
  if (/秒送/.test(bodyText)) return "秒送外卖";
  return "网页渠道";
}

function safeSourceUrl() {
  const url = new URL(location.href);
  url.search = "";
  url.hash = "";
  return url.toString();
}

function collectQuote() {
  const bodyText = cleanText(document.body?.innerText).slice(0, 120000);
  const platform = PLATFORM_RULES.find((rule) => location.hostname.endsWith(rule.host))?.platform || location.hostname;
  const loginBlocked = /请先登录|登录后查看|登录\/注册|扫码登录/.test(bodyText) && !/退出登录|我的订单|个人中心/.test(bodyText);

  const total = findLabeledAmount(["实付", "应付", "合计", "总计", "付款金额", "订单金额"]);
  const itemPrice = findLabeledAmount(["商品小计", "商品金额", "餐品小计", "商品价格"]) ?? prominentPrice();
  const packingFee = findLabeledAmount(["包装费", "餐盒费"]);
  const deliveryFee = findLabeledAmount(["配送费", "运费", "配送服务费"]);
  const serviceFee = findLabeledAmount(["服务费", "技术服务费"]);
  const discount = findLabeledAmount(["已优惠", "优惠合计", "红包", "满减", "优惠券"]);
  const usableTotal = total ?? itemPrice;

  if (loginBlocked) {
    return { ok: false, code: "LOGIN_REQUIRED", error: "当前页面仍处于未登录状态，请先在平台页面完成登录。" };
  }
  if (usableTotal === null) {
    return { ok: false, code: "NO_PRICE", error: "没有在当前可见页面找到价格。请进入商品页或订单确认页后再采集。" };
  }

  const product = findName([
    "h1",
    "[class*='productName']",
    "[class*='product-name']",
    "[class*='food-name']",
    "[class*='title']",
  ], document.title.split(/[-_|]/)[0]);
  const merchant = findName([
    "[class*='shopName']",
    "[class*='shop-name']",
    "[class*='merchant']",
    "[class*='poi-name']",
  ], `${platform}当前页面`);

  return {
    ok: true,
    capture: {
      id: `capture-${Date.now()}`,
      platform,
      channel: detectChannel(bodyText),
      product,
      merchant,
      spec: "以采集页面当前所选规格为准",
      total: usableTotal,
      itemPrice: itemPrice ?? usableTotal,
      packingFee: packingFee ?? 0,
      deliveryFee: deliveryFee ?? 0,
      serviceFee: serviceFee ?? 0,
      discount: discount ?? Math.max(0, (itemPrice ?? usableTotal) + (packingFee ?? 0) + (deliveryFee ?? 0) + (serviceFee ?? 0) - usableTotal),
      sourceStatus: total !== null ? "checkout" : "page",
      sourceUrl: safeSourceUrl(),
      capturedAt: new Date().toISOString(),
      evidence: total !== null ? "检测到实付/合计字段" : "检测到页面商品价格",
    },
  };
}

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message?.type === "PING_COLLECTOR") {
    sendResponse({ ok: true, platform: location.hostname });
    return false;
  }

  if (message?.type === "COLLECT_QUOTE") {
    const result = collectQuote();
    if (!result.ok) {
      sendResponse(result);
      return false;
    }
    chrome.runtime.sendMessage({ type: "SAVE_CAPTURE", capture: result.capture })
      .then((saved) => sendResponse(saved.ok ? { ok: true, capture: result.capture } : saved))
      .catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }
  return false;
});
