/* global chrome */

const STORAGE_KEY = "shengyikou-captures";
const MAX_CAPTURES = 80;

async function readCaptures() {
  const stored = await chrome.storage.local.get(STORAGE_KEY);
  return Array.isArray(stored[STORAGE_KEY]) ? stored[STORAGE_KEY] : [];
}

async function saveCapture(capture) {
  const captures = await readCaptures();
  const duplicateIndex = captures.findIndex((item) =>
    item.sourceUrl === capture.sourceUrl &&
    item.product === capture.product &&
    item.total === capture.total
  );

  if (duplicateIndex >= 0) captures.splice(duplicateIndex, 1);
  captures.unshift(capture);
  await chrome.storage.local.set({ [STORAGE_KEY]: captures.slice(0, MAX_CAPTURES) });
  return captures.slice(0, MAX_CAPTURES);
}

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message?.type === "SAVE_CAPTURE") {
    saveCapture(message.capture)
      .then((captures) => sendResponse({ ok: true, captures }))
      .catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }

  if (message?.type === "GET_CAPTURES") {
    readCaptures()
      .then((captures) => sendResponse({ ok: true, captures }))
      .catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }

  if (message?.type === "CLEAR_CAPTURES") {
    chrome.storage.local.set({ [STORAGE_KEY]: [] })
      .then(() => sendResponse({ ok: true }))
      .catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }
});
