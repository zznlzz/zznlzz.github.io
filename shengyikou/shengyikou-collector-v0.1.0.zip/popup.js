/* global chrome */

const supportedHosts = ["meituan.com", "jd.com", "taobao.com", "ele.me"];
const statusBox = document.getElementById("status");
const statusText = statusBox.querySelector("span");
const collectButton = document.getElementById("collect");
const resultBox = document.getElementById("result");
let activeTab;

function showResult(message, isError = false) {
  resultBox.hidden = false;
  resultBox.classList.toggle("error", isError);
  resultBox.textContent = message;
}

async function inspectCurrentTab() {
  [activeTab] = await chrome.tabs.query({ active: true, currentWindow: true });
  const hostname = activeTab?.url ? new URL(activeTab.url).hostname : "";
  const supported = supportedHosts.some((host) => hostname.endsWith(host));
  statusBox.className = `status ${supported ? "ready" : "error"}`;
  statusText.textContent = supported ? `已连接 ${hostname}` : "请先打开受支持的平台页面";
  collectButton.disabled = !supported;
}

collectButton.addEventListener("click", async () => {
  collectButton.disabled = true;
  collectButton.textContent = "正在读取可见价格…";
  try {
    const response = await chrome.tabs.sendMessage(activeTab.id, { type: "COLLECT_QUOTE" });
    if (!response?.ok) throw new Error(response?.error || "采集失败");
    showResult(`${response.capture.platform} · ${response.capture.channel}\n${response.capture.product}\n采集价：¥${response.capture.total}`);
  } catch (error) {
    showResult(error.message || "采集失败，请刷新平台页面后重试。", true);
  } finally {
    collectButton.disabled = false;
    collectButton.textContent = "采集当前页面价格";
  }
});

document.querySelectorAll("[data-url]").forEach((button) => {
  button.addEventListener("click", () => chrome.tabs.create({ url: button.dataset.url }));
});

document.getElementById("dashboard").addEventListener("click", () => {
  chrome.tabs.create({ url: "https://zznlzz.github.io/shengyikou/" });
});

inspectCurrentTab().catch((error) => showResult(error.message, true));
