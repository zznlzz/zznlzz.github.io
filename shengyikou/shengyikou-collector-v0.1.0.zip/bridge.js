/* global chrome */

const WEB_SOURCE = "shengyikou-web";
const EXTENSION_SOURCE = "shengyikou-extension";

window.postMessage({ source: EXTENSION_SOURCE, type: "SHENGYIKOU_EXTENSION_READY" }, "*");

window.addEventListener("message", (event) => {
  if (event.source !== window || event.data?.source !== WEB_SOURCE) return;
  if (event.data.type !== "SHENGYIKOU_REQUEST_CAPTURES") return;

  chrome.runtime.sendMessage({ type: "GET_CAPTURES" })
    .then((response) => {
      window.postMessage({
        source: EXTENSION_SOURCE,
        type: "SHENGYIKOU_CAPTURES",
        ok: Boolean(response?.ok),
        captures: response?.captures ?? [],
        error: response?.error,
      }, "*");
    })
    .catch((error) => {
      window.postMessage({ source: EXTENSION_SOURCE, type: "SHENGYIKOU_CAPTURES", ok: false, captures: [], error: error.message }, "*");
    });
});
