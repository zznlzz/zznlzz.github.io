/* global chrome */

const WEB_SOURCE = "shengyikou-web";
const EXTENSION_SOURCE = "shengyikou-extension";

function post(type, payload = {}) {
  window.postMessage({ source: EXTENSION_SOURCE, type, ...payload }, "*");
}

post("SHENGYIKOU_EXTENSION_READY", { version: chrome.runtime.getManifest().version });

window.addEventListener("message", (event) => {
  if (event.source !== window || event.data?.source !== WEB_SOURCE) return;
  const message = event.data;

  if (message.type === "SHENGYIKOU_GET_STATUS") {
    chrome.runtime.sendMessage({ type: "GET_PROVIDER_STATUS" })
      .then((response) => post("SHENGYIKOU_PROVIDER_STATUS", response || { ok: false }))
      .catch((error) => post("SHENGYIKOU_PROVIDER_STATUS", { ok: false, error: error.message, note: "无法读取连接状态" }));
    return;
  }

  if (message.type === "SHENGYIKOU_META_SEARCH") {
    post("SHENGYIKOU_SEARCH_PROGRESS", { requestId: message.requestId, note: "本机服务正在并发查询所有已连接平台…" });
    chrome.runtime.sendMessage({ type: "META_SEARCH", input: message.input })
      .then((response) => {
        if (Array.isArray(response?.quotes)) post("SHENGYIKOU_SEARCH_RESULT", { requestId: message.requestId, quotes: response.quotes });
        post("SHENGYIKOU_SEARCH_COMPLETE", {
          requestId: message.requestId,
          ok: Boolean(response?.ok),
          providers: response?.providers,
          note: response?.note || response?.error || "搜索结束",
        });
      })
      .catch((error) => post("SHENGYIKOU_SEARCH_COMPLETE", { requestId: message.requestId, ok: false, note: error.message }));
    return;
  }

  if (message.type === "SHENGYIKOU_CONNECT_PROVIDER") {
    chrome.runtime.sendMessage({ type: "CONNECT_PROVIDER", providerId: message.providerId })
      .then((response) => {
        if (!response?.ok) post("SHENGYIKOU_PROVIDER_STATUS", { ok: false, note: response?.error || "无法打开连接入口" });
      })
      .catch((error) => post("SHENGYIKOU_PROVIDER_STATUS", { ok: false, note: error.message }));
  }
});
