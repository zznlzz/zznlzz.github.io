/* global chrome */

const statusBox = document.getElementById("status");
const statusText = statusBox.querySelector("span");
const details = document.getElementById("details");
const refreshButton = document.getElementById("refresh");

async function refresh() {
  refreshButton.disabled = true;
  statusBox.className = "status";
  statusText.textContent = "正在检查本机聚合服务…";
  try {
    const response = await chrome.runtime.sendMessage({ type: "GET_PROVIDER_STATUS" });
    statusBox.className = `status ${response?.ok ? "ready" : "error"}`;
    statusText.textContent = response?.note || "状态未知";
    details.textContent = (response?.providers || []).map((provider) => `${provider.state === "connected" ? "●" : "○"} ${provider.name}：${provider.detail}`).join("\n");
  } catch (error) {
    statusBox.className = "status error";
    statusText.textContent = error.message;
  } finally {
    refreshButton.disabled = false;
  }
}

refreshButton.addEventListener("click", refresh);
document.getElementById("dashboard").addEventListener("click", () => chrome.tabs.create({ url: "https://zznlzz.github.io/shengyikou/" }));
refresh();
