# 省一口元搜索连接器 v0.2.0

连接器负责在 `https://zznlzz.github.io/shengyikou/` 与本机聚合服务之间转发请求。网页发出一次“商品 + 位置”搜索后，连接器调用 `http://127.0.0.1:17321/v1/search`，再把真实报价和各平台状态回传给网页。

## 安装

1. 解压 `shengyikou-connector-v0.2.0.zip`。
2. Chrome/Edge 打开扩展管理页并启用开发者模式。
3. 选择“加载已解压的扩展程序”，选中包含 `manifest.json` 的 `extension` 文件夹。
4. 在项目目录运行 `npm run broker:start`。
5. 点击扩展图标确认显示“本机元搜索服务已连接”。

## 数据边界

- GitHub Pages 只发送搜索词、位置和是否包含自取。
- 平台密钥、会话、Cookie 和移动端登录态只存在本机适配器中。
- 连接器不自动下单、不领券、不付款。
- 未配置的平台返回 `needs_setup` 或 `needs_mobile`，不会产生模拟报价。

平台适配器协议见 `broker/README.md`。
