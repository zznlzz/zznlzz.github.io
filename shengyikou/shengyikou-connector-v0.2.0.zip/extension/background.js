/* global chrome */

const BROKER_URL = "http://127.0.0.1:17321";
const CONNECT_URLS = {
  meituan: "https://www.meituan.com/",
  jd: "https://www.jd.com/",
  taobao: "https://login.taobao.com/",
  eleme: "https://www.ele.me/",
};

const FALLBACK_PROVIDERS = [
  { id: "meituan", name: "美团", channels: ["外卖", "拼好饭", "神抢手", "团购", "自取"], state: "needs_setup", detail: "本机聚合服务尚未启动", connectUrl: CONNECT_URLS.meituan },
  { id: "jd", name: "京东", channels: ["秒送外卖", "PLUS", "平台券"], state: "needs_setup", detail: "本机聚合服务尚未启动", connectUrl: CONNECT_URLS.jd },
  { id: "taobao", name: "淘宝闪购", channels: ["闪购", "红包", "88VIP"], state: "needs_setup", detail: "本机聚合服务尚未启动", connectUrl: CONNECT_URLS.taobao },
  { id: "eleme", name: "饿了么", channels: ["外卖", "会员", "红包"], state: "needs_setup", detail: "本机聚合服务尚未启动", connectUrl: CONNECT_URLS.eleme },
  { id: "payments", name: "支付优惠", channels: ["招商银行", "数字人民币"], state: "needs_mobile", detail: "需要 Android 真机或模拟器验证 App 专属价与支付优惠" },
];

async function brokerRequest(path, init) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 35_000);
  try {
    const response = await fetch(`${BROKER_URL}${path}`, { ...init, signal: controller.signal });
    const payload = await response.json();
    if (!response.ok || payload.ok === false) throw new Error(payload.error || `本机服务 HTTP ${response.status}`);
    return payload;
  } finally {
    clearTimeout(timer);
  }
}

async function getStatus() {
  try {
    const payload = await brokerRequest("/v1/providers");
    return { ok: true, providers: payload.providers, note: "本机元搜索服务已连接" };
  } catch (error) {
    return {
      ok: false,
      providers: FALLBACK_PROVIDERS,
      note: error.name === "AbortError" ? "本机服务连接超时" : "本机服务尚未启动：请运行 npm run broker:start",
      error: error.message,
    };
  }
}

async function metaSearch(input) {
  return brokerRequest("/v1/search", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify(input),
  });
}

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message?.type === "GET_PROVIDER_STATUS") {
    getStatus().then(sendResponse).catch((error) => sendResponse({ ok: false, providers: FALLBACK_PROVIDERS, error: error.message }));
    return true;
  }

  if (message?.type === "META_SEARCH") {
    metaSearch(message.input)
      .then((payload) => sendResponse({ ok: true, ...payload }))
      .catch(async (error) => {
        const status = await getStatus();
        sendResponse({ ok: false, quotes: [], providers: status.providers, error: error.name === "AbortError" ? "本机搜索超时" : error.message, note: status.note });
      });
    return true;
  }

  if (message?.type === "CONNECT_PROVIDER") {
    const url = CONNECT_URLS[message.providerId];
    if (url) {
      chrome.tabs.create({ url }).then(() => sendResponse({ ok: true })).catch((error) => sendResponse({ ok: false, error: error.message }));
      return true;
    }
    sendResponse({ ok: false, error: "该数据源需要先配置移动端验证器，请查看本机服务说明。" });
    return false;
  }

  return false;
});
